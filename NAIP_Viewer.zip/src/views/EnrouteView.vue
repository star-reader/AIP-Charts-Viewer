<template>
    <Page />
</template>

<script lang='ts' setup>
import Page from '@/components/Enroute.vue'
</script>
