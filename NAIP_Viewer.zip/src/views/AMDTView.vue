<template>
    <Page :is-amdt="true" />
</template>

<script lang='ts' setup>
import Page from '@/components/ChartViewer.vue'
</script>
