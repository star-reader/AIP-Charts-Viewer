<template>
    <Page :is-amdt="false" />
</template>

<script lang='ts' setup>
import Page from '@/components/ChartViewer.vue'
</script>
