export default {
    "Available":"http://154.9.231.76:3034/available.json",
    "BaseFolder":"http://154.9.231.76:3034",
    "CheckAuth":"http://154.9.231.76:3034/login.php"
}